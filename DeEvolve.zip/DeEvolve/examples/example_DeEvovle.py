"""
import numpy as np
import copy
import heapq
import random
from itertools import combinations


def is_UAV_associated(subroute_with_flag):
    return subroute_with_flag[1] != -1


def updatetime(distance_truck, speed_truck, subpath, distance_uav, speed_uav, t):
    for key in t:
        t[key] = 0

    for sub in subpath:
        path = sub[0]
        for i in range(1, len(path) - 1):
            t[path[i]] = t[path[i - 1]] + distance_truck[path[i - 1]][path[i]] / speed_truck

        if sub[1] != -1:
            a = path[0]
            b = path[-1]
            t_u = t[a] + (distance_uav[a][sub[1]] + distance_uav[sub[1]][b]) / speed_uav
            t[path[-1]] = max(t_u, t[path[-2]] + distance_truck[path[-2]][path[-1]] / speed_truck)
        else:
            t[path[-1]] = t[path[-2]] + distance_truck[path[-2]][path[-1]] / speed_truck

    return t


def updatepath(servedbyUAV, best_insert, distance_truck, speed_truck, truckpath, subpath, distance_uav, speed_uav, t,
               C_prime):
    i, j, k = best_insert
    if servedbyUAV:
        truckpath.remove(j)
        for sub in subpath:
            if j in sub[0]:
                sub[0].remove(j)
                break

        for sub in subpath:
            if i in sub[0] and k in sub[0]:
                i_index = sub[0].index(i)
                k_index = sub[0].index(k)
                index = subpath.index(sub)

                subpath.remove(sub)

                if i_index > 0:
                    subpath.insert(index, (sub[0][:i_index + 1], -1))
                if k_index - i_index > 0:
                    subpath.insert(index + 1, (sub[0][i_index:k_index + 1], j))
                if len(sub[0]) - 1 - k_index > 0:
                    subpath.insert(index + 2, (sub[0][k_index:], -1))

                break

        for item in [i, j, k]:
            if item in C_prime:
                C_prime.remove(item)
    else:
        truckpath.remove(j)
        for sub in subpath:
            if j in sub[0]:
                sub[0].remove(j)
                break

        i_index = truckpath.index(i)
        truckpath.insert(i_index + 1, j)
        for sub in subpath:
            if i in sub[0] and k in sub[0]:
                i_sub_index = sub[0].index(i)
                sub[0].insert(i_sub_index + 1, j)
                break

    updatetime(distance_truck, speed_truck, subpath, distance_uav, speed_uav, t)
    return truckpath, subpath, t, C_prime


def caluavcost(j, t, subpath, distance_uav, speed_uav, savings, maxsaving, servedbyUAV, best_insert, e, s_l, s_r):
    path = subpath[0]
    for i_index in range(len(path) - 1):
        i = path[i_index]
        for k_index in range(i_index + 1, len(path) - 1):
            k = path[k_index]
            if i == j or j == k or i == k:
                continue
            tau_i_j_uav = distance_uav[i][j] / speed_uav
            tau_j_k_uav = distance_uav[j][k] / speed_uav

            if tau_i_j_uav + tau_j_k_uav <= e:
                if j in path and i_index < path.index(j) < k_index:
                    t_u_k = t[k] - savings
                else:
                    t_u_k = t[k]
                cost = max(0, max((t_u_k - t[i]) + s_l + s_r, tau_i_j_uav + tau_j_k_uav + s_l + s_r) - (t_u_k - t[i]))

                if savings - cost > maxsaving:
                    maxsaving = savings - cost
                    servedbyUAV = True
                    best_insert = (i, j, k)

    return maxsaving, servedbyUAV, best_insert


def caltruckcost(j, t, distance_truck, speed_truck, sub_path, distance_uav, speed_uav, savings, maxsaving, servedbyUAV,
                 best_insert, e, s_t, s_r):
    path = sub_path[0]
    a = path[0]
    b = path[-1]
    for index in range(len(path) - 1):
        i = path[index]
        k = path[index + 1]

        if i == j or j == k or i == k:
            continue
        cost = (distance_truck[i][j] + distance_truck[j][k] - distance_truck[i][k]) / speed_truck
        t_u_b = s_t + (distance_uav[a][j] + distance_uav[j][b]) / speed_uav + s_r
        t_p_b = t[b] + cost
        if t_u_b - t_p_b > 0:
            cost = max(0, cost - (t_u_b - t_p_b))
        if t[b] - t[a] + cost < e:
            if savings - cost > maxsaving:
                maxsaving = savings - cost
                servedbyUAV = False
                best_insert = (i, j, k)

    return maxsaving, servedbyUAV, best_insert


def saving(j, t, distance_truck, speed_truck, truckpath, trucksubpath, distance_uav, speed_uav, s_r):
    j_index = truckpath.index(j)
    i = truckpath[j_index - 1]
    k = truckpath[j_index + 1]
    savings = (distance_truck[i][j] + distance_truck[j][k] - distance_truck[i][k]) / speed_truck
    for subpath in trucksubpath:
        if j in subpath[0]:
            if is_UAV_associated(subpath):
                a = subpath[0][0]
                b = subpath[0][-1]
                t_u_b = t[a] + (distance_uav[a][subpath[1]] + distance_uav[subpath[1]][b]) / speed_uav + s_r
                t_p_b = t[b] - savings
                if t_p_b < t_u_b:
                    savings = max(0, savings + (t_p_b - t_u_b))
            break
    return savings


def solvetsp(C, distances_truck, truck_speed):
    n = len(C)
    truckRoute = [0]
    visited = {0}
    t = {0: 0}
    current_node = 0

    while len(visited) <= n:
        nearest_node = None
        nearest_distance = float('inf')

        for node in C:
            if node not in visited and distances_truck[current_node][node] < nearest_distance:
                nearest_node = node
                nearest_distance = distances_truck[current_node][node]

        if nearest_node is not None:
            truckRoute.append(nearest_node)
            visited.add(nearest_node)
            t[nearest_node] = t[current_node] + (nearest_distance / truck_speed)
            current_node = nearest_node

    truckRoute.append(0)
    t[0] = t[current_node] + (distances_truck[current_node][0] / truck_speed)
    return truckRoute, t


def genetic_algorithm(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r,
                      population_size=50, generations=100, mutation_rate=0.1):
    def initialize_population():
        population = []
        for _ in range(population_size):
            individual = random.sample(C, len(C))
            population.append(individual)
        return population

    def fitness(individual):
        truckpath = [0] + individual + [0]
        t = {0: 0}
        for i in range(1, len(truckpath)):
            t[truckpath[i]] = t[truckpath[i - 1]] + distances_truck[truckpath[i - 1]][truckpath[i]] / truck_speed
        total_time = t[0]
        return total_time

    def crossover(parent1, parent2):
        size = len(parent1)
        child = [None] * size
        start, end = sorted(random.sample(range(size), 2))
        child[start:end] = parent1[start:end]
        remaining = [item for item in parent2 if item not in child[start:end]]
        ptr = 0
        for i in range(size):
            if child[i] is None:
                child[i] = remaining[ptr]
                ptr += 1
        return child

    def mutate(individual):
        if random.random() < mutation_rate:
            idx1, idx2 = random.sample(range(len(individual)), 2)
            individual[idx1], individual[idx2] = individual[idx2], individual[idx1]
        return individual

    def local_search(individual):
        best_fitness = fitness(individual)
        improved = True
        while improved:
            improved = False
            for i, j in combinations(range(len(individual)), 2):
                new_individual = individual.copy()
                new_individual[i], new_individual[j] = new_individual[j], new_individual[i]
                new_fitness = fitness(new_individual)
                if new_fitness < best_fitness:
                    individual = new_individual
                    best_fitness = new_fitness
                    improved = True
                    break
        return individual

    population = initialize_population()
    for _ in range(generations):
        population = sorted(population, key=lambda x: fitness(x))
        elites = population[:int(0.1 * population_size)]
        offspring = []
        for _ in range(population_size - len(elites)):
            parent1, parent2 = random.choices(population[:int(0.2 * population_size)], k=2)
            child = crossover(parent1, parent2)
            child = mutate(child)
            child = local_search(child)
            offspring.append(child)
        population = elites + offspring

    best_individual = min(population, key=lambda x: fitness(x))
    truckpath = [0] + best_individual + [0]
    t = {0: 0}
    for i in range(1, len(truckpath)):
        t[truckpath[i]] = t[truckpath[i - 1]] + distances_truck[truckpath[i - 1]][truckpath[i]] / truck_speed
    return truckpath, t


def fstsp(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r):
    truckpath, t = genetic_algorithm(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r)
    len_in = len(truckpath)
    trucksubpath = [(copy.deepcopy(truckpath), -1)]

    uav_queue = []
    for j in C_prime:
        savings = saving(j, t, distances_truck, truck_speed, truckpath, trucksubpath, distances_uav, uav_speed, s_r)
        heapq.heappush(uav_queue, (-savings, j))

    insertion_cache = {}

    while uav_queue:
        neg_savings, j = heapq.heappop(uav_queue)
        savings = -neg_savings

        if j not in C_prime:
            continue

        maxsaving = 0
        servedbyUAV = False
        best_insert = None

        if j in insertion_cache:
            maxsaving, servedbyUAV, best_insert = insertion_cache[j]
        else:
            for subpath in trucksubpath:
                if is_UAV_associated(subpath):
                    maxsaving, servedbyUAV, best_insert = caltruckcost(j, t, distances_truck, truck_speed, subpath,
                                                                       distances_uav, uav_speed, savings, maxsaving,
                                                                       servedbyUAV, best_insert, e, s_l, s_r)
                else:
                    maxsaving, servedbyUAV, best_insert = caluavcost(j, t, subpath, distances_uav, uav_speed, savings,
                                                                     maxsaving, servedbyUAV, best_insert, e, s_l, s_r)

            insertion_cache[j] = (maxsaving, servedbyUAV, best_insert)

            if maxsaving <= 0:
                continue

        if maxsaving > 0:
            truckpath, trucksubpath, t, C_prime = updatepath(servedbyUAV, best_insert, distances_truck, truck_speed,
                                                             truckpath, trucksubpath, distances_uav, uav_speed, t,
                                                             C_prime)

            uav_queue = []
            for j in C_prime:
                savings = saving(j, t, distances_truck, truck_speed, truckpath, trucksubpath, distances_uav, uav_speed,
                                 s_r)
                heapq.heappush(uav_queue, (-savings, j))

            insertion_cache = {}

    len_fin = len(truckpath)
    print(f"Initial length: {len_in}, Final length: {len_fin}")
    return trucksubpath, t


def manhattan_distance(point1, point2):
    return abs(point1[0] - point2[0]) + abs(point1[1] - point2[1])


def euclidean_distance(point1, point2):
    return np.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)


def run_delivery_simulation(n_points=5, grid_size=10, truck_speed=1.0, uav_speed=2.0, e=10.0, s_l=0.5, s_r=0.5):
    points = [(0, 0), (70, 63), (25, 43), (55, 15), (8, 45), (8, 46), (47, 11), (54, 69), (61, 39), (11, 40), (28, 23),
              (42, 59),
              (87, 79), (58, 61), (51, 19), (52, 78), (34, 65), (68, 9), (85, 31), (82, 50), (70, 26)]
    C = list(range(1, n_points + 1))
    C_prime = copy.deepcopy(C)

    distances_truck = np.zeros((n_points + 1, n_points + 1))
    distances_uav = np.zeros((n_points + 1, n_points + 1))
    for i in range(n_points + 1):
        for j in range(n_points + 1):
            distances_truck[i][j] = manhattan_distance(points[i], points[j])
            distances_uav[i][j] = euclidean_distance(points[i], points[j])

    trucksubpath, t = fstsp(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r)
    return points, trucksubpath, t


if __name__ == "__main__":
    n_points = 20
    grid_size = 10
    truck_speed = 1.0
    uav_speed = 2.0
    e = 15.0
    s_l = 0.5
    s_r = 0.5

    points, trucksubpath, t = run_delivery_simulation(n_points, grid_size, truck_speed, uav_speed, e, s_l, s_r)

    print("Delivery Points:", points)
    print("Truck Subpaths and UAV Usage:", trucksubpath)
    print("Arrival Times:", t)
"""
import numpy as np
import copy
import heapq
import random
from itertools import combinations
import matplotlib.pyplot as plt

def is_UAV_associated(subroute_with_flag):
    return subroute_with_flag[1] != -1


def updatetime(distance_truck, speed_truck, subpath, distance_uav, speed_uav, t):
    for key in t:
        t[key] = 0

    for sub in subpath:
        path = sub[0]
        for i in range(1, len(path) - 1):
            t[path[i]] = t[path[i - 1]] + distance_truck[path[i - 1]][path[i]] / speed_truck

        if sub[1] != -1:
            a = path[0]
            b = path[-1]
            t_u = t[a] + (distance_uav[a][sub[1]] + distance_uav[sub[1]][b]) / speed_uav
            t[path[-1]] = max(t_u, t[path[-2]] + distance_truck[path[-2]][path[-1]] / speed_truck)
        else:
            t[path[-1]] = t[path[-2]] + distance_truck[path[-2]][path[-1]] / speed_truck

    return t


def updatepath(servedbyUAV, best_insert, distance_truck, speed_truck, truckpath, subpath, distance_uav, speed_uav, t,
               C_prime):
    i, j, k = best_insert
    if servedbyUAV:
        truckpath.remove(j)
        for sub in subpath:
            if j in sub[0]:
                sub[0].remove(j)
                break

        for sub in subpath:
            if i in sub[0] and k in sub[0]:
                i_index = sub[0].index(i)
                k_index = sub[0].index(k)
                index = subpath.index(sub)

                subpath.remove(sub)

                if i_index > 0:
                    subpath.insert(index, (sub[0][:i_index + 1], -1))
                if k_index - i_index > 0:
                    subpath.insert(index + 1, (sub[0][i_index:k_index + 1], j))
                if len(sub[0]) - 1 - k_index > 0:
                    subpath.insert(index + 2, (sub[0][k_index:], -1))

                break

        for item in [i, j, k]:
            if item in C_prime:
                C_prime.remove(item)
    else:
        truckpath.remove(j)
        for sub in subpath:
            if j in sub[0]:
                sub[0].remove(j)
                break

        i_index = truckpath.index(i)
        truckpath.insert(i_index + 1, j)
        for sub in subpath:
            if i in sub[0] and k in sub[0]:
                i_sub_index = sub[0].index(i)
                sub[0].insert(i_sub_index + 1, j)
                break

    updatetime(distance_truck, speed_truck, subpath, distance_uav, speed_uav, t)
    return truckpath, subpath, t, C_prime


def caluavcost(j, t, subpath, distance_uav, speed_uav, savings, maxsaving, servedbyUAV, best_insert, e, s_l, s_r):
    path = subpath[0]
    for i_index in range(len(path) - 1):
        i = path[i_index]
        for k_index in range(i_index + 1, len(path) - 1):
            k = path[k_index]
            if i == j or j == k or i == k:
                continue
            tau_i_j_uav = distance_uav[i][j] / speed_uav
            tau_j_k_uav = distance_uav[j][k] / speed_uav

            if tau_i_j_uav + tau_j_k_uav <= e:
                if j in path and i_index < path.index(j) < k_index:
                    t_u_k = t[k] - savings
                else:
                    t_u_k = t[k]
                cost = max(0, max((t_u_k - t[i]) + s_l + s_r, tau_i_j_uav + tau_j_k_uav + s_l + s_r) - (t_u_k - t[i]))

                if savings - cost > maxsaving:
                    maxsaving = savings - cost
                    servedbyUAV = True
                    best_insert = (i, j, k)

    return maxsaving, servedbyUAV, best_insert


def caltruckcost(j, t, distance_truck, speed_truck, sub_path, distance_uav, speed_uav, savings, maxsaving, servedbyUAV,
                 best_insert, e, s_t, s_r):
    path = sub_path[0]
    a = path[0]
    b = path[-1]
    for index in range(len(path) - 1):
        i = path[index]
        k = path[index + 1]

        if i == j or j == k or i == k:
            continue
        cost = (distance_truck[i][j] + distance_truck[j][k] - distance_truck[i][k]) / speed_truck
        t_u_b = s_t + (distance_uav[a][j] + distance_uav[j][b]) / speed_uav + s_r
        t_p_b = t[b] + cost
        if t_u_b - t_p_b > 0:
            cost = max(0, cost - (t_u_b - t_p_b))
        if t[b] - t[a] + cost < e:
            if savings - cost > maxsaving:
                maxsaving = savings - cost
                servedbyUAV = False
                best_insert = (i, j, k)

    return maxsaving, servedbyUAV, best_insert


def saving(j, t, distance_truck, speed_truck, truckpath, trucksubpath, distance_uav, speed_uav, s_r):
    j_index = truckpath.index(j)
    i = truckpath[j_index - 1]
    k = truckpath[j_index + 1]
    savings = (distance_truck[i][j] + distance_truck[j][k] - distance_truck[i][k]) / speed_truck
    for subpath in trucksubpath:
        if j in subpath[0]:
            if is_UAV_associated(subpath):
                a = subpath[0][0]
                b = subpath[0][-1]
                t_u_b = t[a] + (distance_uav[a][subpath[1]] + distance_uav[subpath[1]][b]) / speed_uav + s_r
                t_p_b = t[b] - savings
                if t_p_b < t_u_b:
                    savings = max(0, savings + (t_p_b - t_u_b))
            break
    return savings


def solvetsp(C, distances_truck, truck_speed):
    n = len(C)
    truckRoute = [0]
    visited = {0}
    t = {0: 0}
    current_node = 0

    while len(visited) <= n:
        nearest_node = None
        nearest_distance = float('inf')

        for node in C:
            if node not in visited and distances_truck[current_node][node] < nearest_distance:
                nearest_node = node
                nearest_distance = distances_truck[current_node][node]

        if nearest_node is not None:
            truckRoute.append(nearest_node)
            visited.add(nearest_node)
            t[nearest_node] = t[current_node] + (nearest_distance / truck_speed)
            current_node = nearest_node

    truckRoute.append(0)
    t[0] = t[current_node] + (distances_truck[current_node][0] / truck_speed)
    return truckRoute, t


def genetic_algorithm(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r,
                      population_size=50, generations=100, mutation_rate=0.1):
    def initialize_population():
        population = []
        for _ in range(population_size):
            individual = random.sample(C, len(C))
            population.append(individual)
        return population

    def fitness(individual):
        truckpath = [0] + individual + [0]
        t = {0: 0}
        for i in range(1, len(truckpath)):
            t[truckpath[i]] = t[truckpath[i - 1]] + distances_truck[truckpath[i - 1]][truckpath[i]] / truck_speed
        total_time = t[0]
        return total_time

    def crossover(parent1, parent2):
        size = len(parent1)
        child = [None] * size
        start, end = sorted(random.sample(range(size), 2))
        child[start:end] = parent1[start:end]
        remaining = [item for item in parent2 if item not in child[start:end]]
        ptr = 0
        for i in range(size):
            if child[i] is None:
                child[i] = remaining[ptr]
                ptr += 1
        return child

    def mutate(individual):
        if random.random() < mutation_rate:
            idx1, idx2 = random.sample(range(len(individual)), 2)
            individual[idx1], individual[idx2] = individual[idx2], individual[idx1]
        return individual

    def local_search(individual):
        best_fitness = fitness(individual)
        improved = True
        while improved:
            improved = False
            for i, j in combinations(range(len(individual)), 2):
                new_individual = individual.copy()
                new_individual[i], new_individual[j] = new_individual[j], new_individual[i]
                new_fitness = fitness(new_individual)
                if new_fitness < best_fitness:
                    individual = new_individual
                    best_fitness = new_fitness
                    improved = True
                    break
        return individual

    population = initialize_population()
    for _ in range(generations):
        population = sorted(population, key=lambda x: fitness(x))
        elites = population[:int(0.1 * population_size)]
        offspring = []
        for _ in range(population_size - len(elites)):
            parent1, parent2 = random.choices(population[:int(0.2 * population_size)], k=2)
            child = crossover(parent1, parent2)
            child = mutate(child)
            child = local_search(child)
            offspring.append(child)
        population = elites + offspring

    best_individual = min(population, key=lambda x: fitness(x))
    truckpath = [0] + best_individual + [0]
    t = {0: 0}
    for i in range(1, len(truckpath)):
        t[truckpath[i]] = t[truckpath[i - 1]] + distances_truck[truckpath[i - 1]][truckpath[i]] / truck_speed
    return truckpath, t


def fstsp(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r):
    truckpath, t = genetic_algorithm(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r)
    len_in = len(truckpath)
    trucksubpath = [(copy.deepcopy(truckpath), -1)]

    uav_queue = []
    for j in C_prime:
        savings = saving(j, t, distances_truck, truck_speed, truckpath, trucksubpath, distances_uav, uav_speed, s_r)
        heapq.heappush(uav_queue, (-savings, j))

    insertion_cache = {}

    while uav_queue:
        neg_savings, j = heapq.heappop(uav_queue)
        savings = -neg_savings

        if j not in C_prime:
            continue

        maxsaving = 0
        servedbyUAV = False
        best_insert = None

        if j in insertion_cache:
            maxsaving, servedbyUAV, best_insert = insertion_cache[j]
        else:
            for subpath in trucksubpath:
                if is_UAV_associated(subpath):
                    maxsaving, servedbyUAV, best_insert = caltruckcost(j, t, distances_truck, truck_speed, subpath,
                                                                       distances_uav, uav_speed, savings, maxsaving,
                                                                       servedbyUAV, best_insert, e, s_l, s_r)
                else:
                    maxsaving, servedbyUAV, best_insert = caluavcost(j, t, subpath, distances_uav, uav_speed, savings,
                                                                     maxsaving, servedbyUAV, best_insert, e, s_l, s_r)

            insertion_cache[j] = (maxsaving, servedbyUAV, best_insert)

            if maxsaving <= 0:
                continue

        if maxsaving > 0:
            truckpath, trucksubpath, t, C_prime = updatepath(servedbyUAV, best_insert, distances_truck, truck_speed,
                                                             truckpath, trucksubpath, distances_uav, uav_speed, t,
                                                             C_prime)

            uav_queue = []
            for j in C_prime:
                savings = saving(j, t, distances_truck, truck_speed, truckpath, trucksubpath, distances_uav, uav_speed,
                                 s_r)
                heapq.heappush(uav_queue, (-savings, j))

            insertion_cache = {}

    len_fin = len(truckpath)
    print(f"Initial length: {len_in}, Final length: {len_fin}")
    return trucksubpath, t


def manhattan_distance(point1, point2):
    return abs(point1[0] - point2[0]) + abs(point1[1] - point2[1])


def euclidean_distance(point1, point2):
    return np.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)


def run_delivery_simulation(n_points=5, grid_size=10, truck_speed=1.0, uav_speed=2.0, e=10.0, s_l=0.5, s_r=0.5):
    points = [(0, 0), (84, 36), (38, 86), (88, 65), (73, 57), (60, 88), (5, 63), (23, 59), (33, 71), (52, 17), (7, 40),
              (25, 89),
              (31, 83), (78, 43), (19, 49), (19, 26), (21, 6), (10, 33), (75, 35), (20, 81), (75, 65)]
    C = list(range(1, n_points + 1))
    C_prime = copy.deepcopy(C)

    distances_truck = np.zeros((n_points + 1, n_points + 1))
    distances_uav = np.zeros((n_points + 1, n_points + 1))
    for i in range(n_points + 1):
        for j in range(n_points + 1):
            distances_truck[i][j] = manhattan_distance(points[i], points[j])
            distances_uav[i][j] = euclidean_distance(points[i], points[j])

    trucksubpath, t = fstsp(C, C_prime, distances_truck, truck_speed, e, distances_uav, uav_speed, s_l, s_r)
    return points, trucksubpath, t


if __name__ == "__main__":
    n_points = 20
    grid_size = 10
    truck_speed = 1.0
    uav_speed = 2.0
    e = 15.0
    s_l = 0.5
    s_r = 0.5

    points, trucksubpath, t = run_delivery_simulation(n_points, grid_size, truck_speed, uav_speed, e, s_l, s_r)

    print("Delivery Points:", points)
    print("Truck Subpaths and UAV Usage:", trucksubpath)
    print("Arrival Times:", t)

    # Reorder trucksubpath for continuity if needed
    ordered_subpaths = []
    remaining = list(trucksubpath)
    if remaining:
        current_start = remaining[0][0][0]  # Start with the first node of the first subpath
        while remaining:
            found = False
            for sub in remaining:
                if sub[0][0] == current_start:
                    ordered_subpaths.append(sub)
                    current_start = sub[0][-1]  # Update to the last node of the current subpath
                    remaining.remove(sub)
                    found = True
                    break
            if not found:
                break  # If no continuous path is found, stop

    # If no continuous order was found or paths are unchanged, use original order
    if not ordered_subpaths:
        ordered_subpaths = trucksubpath

    # Path visualization
    plt.figure(figsize=(10, 8))
    for i, p in enumerate(points):
        color = 'green' if i == 0 else 'black'
        marker = 's' if i == 0 else 'o'
        plt.plot(p[0], p[1], marker=marker, color=color)
        plt.text(p[0] + 1, p[1] + 1, str(i), fontsize=12)

    # Add legend for warehouse
    plt.plot([], [], 'gs', label='Warehouse')

    # Construct full truck path by concatenating subpaths
    truck_points = []
    for sub in ordered_subpaths:
        for node in sub[0]:
            if not truck_points or truck_points[-1] != node:
                truck_points.append(node)

    # Plot truck path with arrows
    for idx in range(len(truck_points) - 1):
        start = truck_points[idx]
        end = truck_points[idx + 1]
        dx = points[end][0] - points[start][0]
        dy = points[end][1] - points[start][1]
        plt.arrow(points[start][0], points[start][1], dx, dy, head_width=1.5, width=0.1, color='blue', length_includes_head=True)

    # Add legend for truck path
    plt.plot([], [], 'b-', label='Truck Path')

    # Plot drone paths with arrows
    drone_label_added = False
    for sub in ordered_subpaths:
        if sub[1] != -1:
            launch = sub[0][0]
            rend = sub[0][-1]
            drone = sub[1]
            # Arrow from launch to drone
            dx1 = points[drone][0] - points[launch][0]
            dy1 = points[drone][1] - points[launch][1]
            plt.arrow(points[launch][0], points[launch][1], dx1, dy1, head_width=1.5, width=0.1, color='red', length_includes_head=True, linestyle='--')
            # Arrow from drone to rend
            dx2 = points[rend][0] - points[drone][0]
            dy2 = points[rend][1] - points[drone][1]
            plt.arrow(points[drone][0], points[drone][1], dx2, dy2, head_width=1.5, width=0.1, color='red', length_includes_head=True, linestyle='--')
            if not drone_label_added:
                plt.plot([], [], 'r--', label='Drone Path')
                drone_label_added = True

    plt.title('Truck-Drone Delivery Paths')
    plt.xlabel('X Coordinate')
    plt.ylabel('Y Coordinate')
    plt.legend()
    plt.grid(True)
    plt.show()